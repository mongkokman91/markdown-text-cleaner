/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  Share2, 
  Copy, 
  Download, 
  Check, 
  Trash2, 
  Play, 
  FileText, 
  Smartphone, 
  Code2, 
  Info, 
  Sun, 
  Moon, 
  RefreshCw, 
  ExternalLink,
  ChevronRight,
  ClipboardPaste,
  FileCode
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Sample texts to make the simulator easy and fun to test
const PRESETS = [
  {
    name: "AI Prompt Draft",
    text: `Act as a senior software engineer.


    Please review this code for me.     I want to make sure there are no performance bottle-necks or security issues.
    
    
    Here is the code:
    const x = 42;
    
    Let me know what you think!   `
  },
  {
    name: "Dirty Markdown Logs",
    text: `### System Status Report
    
    
    - Database:   Connected   
    - Redis Cache:  Active
    
    
    Errors: None detected.
    
    
    [Finished in 0.4s]`
  },
  {
    name: "Excessive Whitespace Log",
    text: "   This   is   a   document   with   tabs\tand\tnewlines\r\nand weird spacing      that needs      cleaning.   "
  }
];

export default function App() {
  const [inputText, setInputText] = useState(PRESETS[0].text);
  const [cleanedText, setCleanedText] = useState("");
  const [hasShared, setHasShared] = useState(false);
  const [activeTab, setActiveTab] = useState<'app' | 'source'>('app');
  const [selectedFile, setSelectedFile] = useState<string>('MainActivity.kt');
  const [isSimDark, setIsSimDark] = useState<boolean>(true);
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);
  const [sharedNotification, setSharedNotification] = useState<boolean>(false);

  // Auto clean text when sharing or updating input in real-time
  const cleanText = (text: string): string => {
    // a) Replace all line breaks, newlines (\n), and carriage returns (\r) with a single space.
    let result = text.replace(/[\r\n]+/g, ' ');
    // b) Replace all double/multiple spaces, tabs, and excess whitespace with a single space.
    result = result.replace(/\s+/g, ' ');
    // c) Trim any trailing or leading whitespace from the start and end of the document.
    return result.trim();
  };

  // Run initial cleaning
  useEffect(() => {
    if (hasShared) {
      setCleanedText(cleanText(inputText));
    } else {
      setCleanedText("");
    }
  }, [inputText, hasShared]);

  const handleShareToApp = (text: string) => {
    setInputText(text);
    setHasShared(true);
    setActiveTab('app');
  };

  const handleManualClean = () => {
    setHasShared(true);
  };

  const handleClear = () => {
    setHasShared(false);
    setCleanedText("");
    setInputText("");
  };

  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  const handleTriggerReShare = () => {
    if (navigator.share) {
      navigator.share({
        text: cleanedText,
        title: "Cleaned Markdown Text"
      }).catch(err => {
        // Fallback to clipboard
        handleCopyToClipboard(cleanedText);
      });
    } else {
      handleCopyToClipboard(cleanedText);
      setSharedNotification(true);
      setTimeout(() => setSharedNotification(false), 2000);
    }
  };

  const handleSaveAsMdFile = () => {
    const element = document.createElement("a");
    const file = new Blob([cleanedText], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = "Cleaned_AI_Prompt.md";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const wordCount = cleanedText ? cleanedText.split(/\s+/).filter(Boolean).length : 0;
  const charCount = cleanedText ? cleanedText.length : 0;

  const rawWordCount = inputText ? inputText.split(/\s+/).filter(Boolean).length : 0;
  const rawCharCount = inputText ? inputText.length : 0;

  // Code contents for the code viewer tab
  const getFileContent = (filename: string) => {
    switch (filename) {
      case 'MainActivity.kt':
        return `package com.example.markdowntextcleaner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.markdowntextcleaner.ui.theme.MarkdownTextCleanerTheme
import java.io.BufferedWriter
import java.io.OutputStreamWriter

class MainActivity : ComponentActivity() {

    private var cleanedText by mutableStateOf("")

    // Activity Result Launcher for SAF Create Document
    private val createDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri: Uri? ->
        if (uri != null) {
            saveTextToUri(uri)
        } else {
            Toast.makeText(this, "Save cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle incoming share intent
        handleIntent(intent)

        setContent {
            MarkdownTextCleanerTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        @OptIn(ExperimentalMaterial3Api::class)
                        TopAppBar(
                            title = { Text("Markdown Text Cleaner") },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    },
                    floatingActionButton = {
                        ExtendedFloatingActionButton(
                            onClick = {
                                if (cleanedText.isNotEmpty()) {
                                    createDocumentLauncher.launch("Cleaned_AI_Prompt.md")
                                } else {
                                    Toast.makeText(this, "No text to save", Toast.LENGTH_SHORT).show()
                                }
                            },
                            icon = { Icon(painterResource(id = R.drawable.ic_save), "Save") },
                            text = { Text("Save as .md") }
                        )
                    }
                ) { innerPadding ->
                    MainScreen(
                        modifier = Modifier.padding(innerPadding),
                        cleanedText = cleanedText,
                        onTextChanged = { cleanedText = it },
                        onShareClicked = { shareCleanedText() }
                    )
                }
            }
        }
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (sharedText != null) {
                cleanedText = cleanMarkdownText(sharedText)
            }
        }
    }

    private fun cleanMarkdownText(text: String): String {
        // a) Replace all line breaks, newlines (\\n), and carriage returns (\\r) with a single space.
        var result = text.replace(Regex("[\\\\r\\\\n]+"), " ")
        // b) Replace all double/multiple spaces, tabs, and excess whitespace with a single space.
        result = result.replace(Regex("\\\\s+"), " ")
        // c) Trim any trailing or leading whitespace from the start and end of the document.
        return result.trim()
    }

    private fun shareCleanedText() {
        if (cleanedText.isEmpty()) return
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, cleanedText)
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, "Share Cleaned Text"))
    }

    private fun saveTextToUri(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { outputStream ->
                BufferedWriter(OutputStreamWriter(outputStream)).use { writer ->
                    writer.write(cleanedText)
                }
            }
            Toast.makeText(this, "Saved successfully!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to save", Toast.LENGTH_LONG).show()
        }
    }
}`;
      case 'AndroidManifest.xml':
        return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Markdown Text Cleaner"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MarkdownTextCleaner">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="Markdown Text Cleaner"
            android:theme="@style/Theme.MarkdownTextCleaner">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            
            <!-- Intent Filter to register as a Share Target for plain text -->
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>
        </activity>
    </application>

</manifest>`;
      case 'build.gradle.kts':
        return `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.markdowntextcleaner"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.markdowntextcleaner"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        vectorDrawables { useSupportLibrary = true }
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.11" }
}`;
      case 'settings.gradle.kts':
        return `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Markdown Text Cleaner"
include(":app")`;
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Header & Brand bar */}
      <header className="border-b border-slate-800 bg-slate-900 px-6 py-4 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2.5 rounded-xl text-white shadow-lg shadow-indigo-900/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl tracking-tight text-white flex items-center gap-2">
              Markdown Text Cleaner
              <span className="text-xs bg-indigo-500/20 text-indigo-400 font-mono px-2 py-0.5 rounded-full border border-indigo-500/30">
                Android Utility
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-sans">
              Jetpack Compose & Material 3 Native Design + Live Web Simulator
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('app')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'app' 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            Interactive Simulator
          </button>
          <button
            onClick={() => setActiveTab('source')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'source' 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <FileCode className="w-4 h-4" />
            Android Source Code
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {activeTab === 'app' ? (
          <>
            {/* Left Column: Share Action Simulator & Presets */}
            <section className="lg:col-span-5 space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Play className="w-5 h-5 text-indigo-400" />
                  <h2 className="font-display font-semibold text-base text-slate-200">
                    Step 1: Simulate Android Share Sheet
                  </h2>
                </div>
                
                <p className="text-xs text-slate-400 leading-relaxed">
                  In a real Android system, when you select some text in any app (like Chrome, Google Keep, or a chat) and tap <strong className="text-slate-200">"Share"</strong>, you can select <strong className="text-slate-200">"Markdown Text Cleaner"</strong> to clean the formatting instantly. Simulate that behavior below:
                </p>

                {/* Presets Grid */}
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                    Pick a Dirty Text Preset:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {PRESETS.map((preset, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleShareToApp(preset.text)}
                        className="px-3 py-2 bg-slate-800/80 border border-slate-700/60 hover:border-indigo-500 rounded-xl text-xs text-slate-300 text-left transition-all hover:bg-slate-800 flex flex-col justify-between"
                      >
                        <span className="font-medium text-slate-200 truncate w-full">{preset.name}</span>
                        <span className="text-[10px] text-slate-500 mt-1">Select to share</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Manual Text Input Area */}
                <div className="space-y-2 pt-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex justify-between">
                    <span>Or write/paste custom dirty text:</span>
                    <span className="text-slate-500">{rawWordCount} words | {rawCharCount} chars</span>
                  </label>
                  <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Type or paste messy text here (with excess line-breaks, triple-spaces, tabs...)"
                    className="w-full h-44 bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm font-mono text-slate-300 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
                  />
                </div>

                {/* Simulated Trigger Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => handleShareToApp(inputText)}
                    className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl text-sm font-semibold text-white shadow-lg shadow-indigo-900/20 transition-all flex items-center justify-center gap-2 group"
                  >
                    <Share2 className="w-4 h-4 transition-transform group-hover:scale-110" />
                    Simulate "Share to App"
                  </button>
                  {hasShared && (
                    <button
                      onClick={handleClear}
                      className="px-4 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300 text-sm transition-all"
                      title="Clear Shared Text"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Guide/Explainers */}
              <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2">
                  <Info className="w-4 h-4 text-emerald-400" />
                  <h3 className="font-display font-semibold text-xs text-slate-300 uppercase tracking-wider">
                    How the Native Integration works
                  </h3>
                </div>
                <ul className="text-xs text-slate-400 space-y-2 list-disc pl-4 leading-relaxed">
                  <li>
                    <strong className="text-slate-300">Share Target:</strong> The app registers an intent filter for <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-400 font-mono">"text/plain"</code> mimeType inside the AndroidManifest.xml.
                  </li>
                  <li>
                    <strong className="text-slate-300">Regex Logic:</strong> All incoming line breaks, redundant spacing, and trailing spacing are parsed and normalized instantly in memory.
                  </li>
                  <li>
                    <strong className="text-slate-300">Storage Access Framework:</strong> Writing file relies on Android's native SAF file dialog, letting users safely write .md files to any local folder or cloud drive.
                  </li>
                </ul>
              </div>
            </section>

            {/* Right Column: High-Fidelity Material 3 Phone Device Mockup */}
            <section className="lg:col-span-7 flex flex-col items-center justify-center">
              
              {/* Phone Frame */}
              <div className="w-full max-w-[430px] bg-slate-900 rounded-[48px] p-4.5 shadow-2xl border-4 border-slate-800 relative ring-12 ring-slate-900/50">
                
                {/* Phone Speaker Notch */}
                <div className="absolute top-7 left-1/2 -translate-x-1/2 w-32 h-5 bg-black rounded-full z-30 flex items-center justify-center">
                  <div className="w-12 h-1 bg-slate-800 rounded-full" />
                </div>

                {/* Simulator Theme Controller Toggle */}
                <div className="absolute right-8 top-18 z-40">
                  <button 
                    onClick={() => setIsSimDark(!isSimDark)}
                    className={`p-2 rounded-full shadow-lg border transition-all ${
                      isSimDark 
                        ? 'bg-neutral-800 text-amber-400 border-neutral-700 hover:bg-neutral-700' 
                        : 'bg-white text-indigo-600 border-slate-200 hover:bg-slate-50'
                    }`}
                    title="Toggle Simulator Theme"
                  >
                    {isSimDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </button>
                </div>

                {/* Phone Screen Canvas */}
                <div className={`w-full aspect-[9/19] rounded-[38px] overflow-hidden flex flex-col relative transition-colors duration-300 select-none ${
                  isSimDark ? 'bg-neutral-950 text-neutral-100' : 'bg-neutral-50 text-neutral-900'
                }`}>
                  
                  {/* Android Status Bar */}
                  <div className={`h-11 px-6 pt-5 flex justify-between items-center text-xs font-mono font-semibold transition-colors ${
                    isSimDark ? 'bg-neutral-950 text-neutral-400' : 'bg-neutral-50 text-neutral-500'
                  }`}>
                    <span>10:42 AM</span>
                    <div className="flex items-center gap-1.5">
                      <span>5G</span>
                      <div className="w-5 h-2.5 border rounded-sm flex p-0.5 items-center">
                        <div className={`h-full w-4/5 rounded-2xs ${isSimDark ? 'bg-neutral-400' : 'bg-neutral-500'}`} />
                      </div>
                    </div>
                  </div>

                  {/* Material 3 Top App Bar */}
                  <div className={`px-6 py-4 flex items-center justify-between border-b transition-colors ${
                    isSimDark 
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-100' 
                      : 'bg-indigo-50 border-indigo-100 text-indigo-950'
                  }`}>
                    <div>
                      <h3 className="font-display font-bold text-base tracking-tight">
                        Markdown Text Cleaner
                      </h3>
                      <p className="text-[10px] opacity-75 font-sans">
                        Jetpack Compose • M3
                      </p>
                    </div>
                  </div>

                  {/* App Content inside Phone */}
                  <div className="flex-1 p-4 flex flex-col gap-4 overflow-y-auto pb-24 relative">
                    
                    {/* Status Indicator Bar */}
                    <div className={`p-4 rounded-2xl border transition-colors ${
                      isSimDark 
                        ? 'bg-neutral-900/60 border-neutral-800' 
                        : 'bg-indigo-50/50 border-indigo-100/50'
                    }`}>
                      <p className={`text-xs font-medium font-display leading-tight ${
                        isSimDark ? 'text-neutral-300' : 'text-indigo-900'
                      }`}>
                        Text Processed: <span className="font-bold text-indigo-500 font-mono">{wordCount}</span> words | <span className="font-bold text-indigo-500 font-mono">{charCount}</span> characters
                      </p>
                    </div>

                    {!hasShared ? (
                      /* Empty State Simulator */
                      <div className="flex-1 flex flex-col items-center justify-center text-center p-4">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 ${
                          isSimDark ? 'bg-neutral-900 text-neutral-500' : 'bg-neutral-200 text-neutral-600'
                        }`}>
                          <Share2 className="w-6 h-6 animate-pulse" />
                        </div>
                        <h4 className="text-sm font-semibold mb-1">No shared text captured</h4>
                        <p className={`text-xs max-w-[200px] mb-4 ${isSimDark ? 'text-neutral-500' : 'text-neutral-500'}`}>
                          Use the panel on the left to simulate sharing a text to this applet.
                        </p>
                        <button
                          onClick={handleManualClean}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full text-xs font-semibold shadow-md transition-all active:scale-95"
                        >
                          Paste Text Manually
                        </button>
                      </div>
                    ) : (
                      /* Active Screen Showing Cleaned Preview */
                      <div className="flex-1 flex flex-col gap-3 min-h-0">
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold uppercase tracking-wider ${
                            isSimDark ? 'text-neutral-400' : 'text-neutral-600'
                          }`}>
                            Cleaned Text Preview:
                          </span>
                          <div className="flex gap-1">
                            <button
                              onClick={() => handleCopyToClipboard(cleanedText)}
                              className={`p-1.5 rounded-lg transition-all ${
                                isSimDark ? 'hover:bg-neutral-800 text-neutral-400' : 'hover:bg-neutral-200 text-neutral-600'
                              }`}
                              title="Copy to Clipboard"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            <button
                              onClick={handleTriggerReShare}
                              className={`p-1.5 rounded-lg transition-all ${
                                isSimDark ? 'hover:bg-neutral-800 text-neutral-400' : 'hover:bg-neutral-200 text-neutral-600'
                              }`}
                              title="Share out"
                            >
                              <Share2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* Cleaned text viewing canvas */}
                        <div className={`flex-1 rounded-xl p-3 border font-mono text-xs overflow-y-auto whitespace-pre-wrap select-text leading-relaxed ${
                          isSimDark 
                            ? 'bg-neutral-900 border-neutral-800 text-neutral-300' 
                            : 'bg-white border-neutral-200 text-neutral-700'
                        }`}>
                          {cleanedText}
                        </div>

                        {/* Reset / Manual Paste back */}
                        <div className="flex justify-end pt-1">
                          <button
                            onClick={handleClear}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                              isSimDark 
                                ? 'bg-neutral-900 text-red-400 hover:bg-neutral-800' 
                                : 'bg-red-50 text-red-600 hover:bg-red-100'
                            }`}
                          >
                            Clear App State
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Material 3 Floating Action Button (FAB) */}
                  <AnimatePresence>
                    {hasShared && cleanedText && (
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="absolute bottom-6 right-6 z-20"
                      >
                        <button
                          onClick={handleSaveAsMdFile}
                          className="flex items-center gap-2 px-5 py-4 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-2xl shadow-xl shadow-indigo-950/40 transition-all font-semibold font-display text-xs"
                        >
                          <Download className="w-4 h-4" />
                          Save as .md
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Android Bottom Navigation Bar Bar */}
                  <div className={`h-12 flex items-center justify-center transition-colors ${
                    isSimDark ? 'bg-neutral-950' : 'bg-neutral-50'
                  }`}>
                    <div className="w-32 h-1 bg-neutral-600 rounded-full" />
                  </div>

                </div>
              </div>

              {/* Status Notifications */}
              <div className="h-6 mt-4">
                <AnimatePresence>
                  {copiedNotification && (
                    <motion.span
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-3 py-1 rounded-full font-medium"
                    >
                      Copied to clipboard successfully!
                    </motion.span>
                  )}
                  {sharedNotification && (
                    <motion.span
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs px-3 py-1 rounded-full font-medium"
                    >
                      Resharing text triggered!
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>

            </section>
          </>
        ) : (
          /* Source Code Viewer View */
          <div className="lg:col-span-12 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 w-full">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <Code2 className="w-5 h-5 text-indigo-400" />
                <div>
                  <h2 className="font-display font-semibold text-lg text-slate-200">
                    Native Android Project Files
                  </h2>
                  <p className="text-xs text-slate-400">
                    Kotlin 1.9.x, Jetpack Compose, and Material 3 design spec.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
                {[
                  'MainActivity.kt',
                  'AndroidManifest.xml',
                  'build.gradle.kts',
                  'settings.gradle.kts'
                ].map((file) => (
                  <button
                    key={file}
                    onClick={() => setSelectedFile(file)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono transition-all ${
                      selectedFile === file 
                        ? 'bg-indigo-600 text-white shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    {file}
                  </button>
                ))}
              </div>
            </div>

            {/* Code canvas */}
            <div className="relative">
              <button
                onClick={() => handleCopyToClipboard(getFileContent(selectedFile))}
                className="absolute right-4 top-4 bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-300 p-2 rounded-lg border border-slate-700/60 transition-all flex items-center gap-1 text-xs font-medium"
                title="Copy File Content"
              >
                <Copy className="w-3.5 h-3.5" />
                Copy File
              </button>
              
              <pre className="w-full bg-slate-950 border border-slate-800 rounded-xl p-5 overflow-x-auto text-xs font-mono text-slate-300 leading-relaxed max-h-[500px]">
                <code>
                  {getFileContent(selectedFile)}
                </code>
              </pre>
            </div>

            <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/40 flex items-start gap-3">
              <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-400 space-y-1">
                <p className="font-medium text-slate-200">Where are these files located?</p>
                <p>
                  These native files are generated inside the <code className="bg-slate-950 text-indigo-400 font-mono px-1 rounded">/android</code> directory of this applet workspace. When you click <strong className="text-slate-300">"Export ZIP"</strong> or <strong className="text-slate-300">"Export to GitHub"</strong> via the top-right settings icon, you'll have the complete, ready-to-run Android Studio project instantly.
                </p>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500 font-sans">
        Markdown Text Cleaner App • Manufactured with Material 3 Design Specifications. All operations run entirely in-memory offline.
      </footer>

    </div>
  );
}
